//Numpy array shape [5, 3]
//Min -1.781250000000
//Max 0.000000000000
//Number of zeros 13

#ifndef W14_H_
#define W14_H_

#ifndef __SYNTHESIS__
weight14_t w14[15];
#else
weight14_t w14[15] = {0.00000, -1.78125, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, -1.68750, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000};
#endif

#endif
