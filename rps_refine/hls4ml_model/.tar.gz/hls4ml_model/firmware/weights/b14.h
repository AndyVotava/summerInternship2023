//Numpy array shape [3]
//Min -0.343750000000
//Max 0.281250000000
//Number of zeros 0

#ifndef B14_H_
#define B14_H_

#ifndef __SYNTHESIS__
bias14_t b14[3];
#else
bias14_t b14[3] = {0.28125, 0.12500, -0.34375};
#endif

#endif
